package byow.InputDemo;

/**
 * Created by hug.
 */
public interface InputSource {
    public char getNextKey();
    public boolean possibleNextInput();
}
